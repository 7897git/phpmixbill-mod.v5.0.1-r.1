<?php 
$koneksi =mysqli_connect("localhost","id14626018_anwar","!5rysbijYg*g#mVw)Zea","id14626018_kodular");

//cek koneksi
if (mysqli_connect_error()){
	echo "Konksi database gagal :". mysqli_connect_error();
} ?>