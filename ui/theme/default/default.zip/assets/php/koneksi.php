<?php

$dbHost = "localhost";
$dbUser = "root";
$dbPass = "";
$db = "_mixbil";

$conn = mysqli_connect($dbHost, $dbUser, $dbPass, $db);
?>